# Namma Bangalore Delivery — Android starter project

This is a **prototype Android Studio project**, not a production-ready marketplace and not a precompiled APK.

## Included
- Android launcher app wrapping a local offline demo screen
- Food, groceries and electronics categories
- Sample products, search and a local cart
- Shop registration form preview
- Admin dashboard preview

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio (`File > Open`).
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Important before public launch
This demo does not include a live server/database, real vendor accounts, secure admin authentication, live order dispatch/tracking, payment gateway, notifications, maps, or production privacy/security controls. Those require backend services, credentials, testing, and deployment. Do not use the demo admin screen to manage real customers or orders.
